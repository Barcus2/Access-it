#pragma once
#include <vector>

namespace carrom {

struct Vector2D {
    float x;
    float y;

    Vector2D operator+(const Vector2D& o) const;
    Vector2D operator-(const Vector2D& o) const;
    Vector2D operator*(float s) const;
    Vector2D operator/(float s) const;
    float dot(const Vector2D& o) const;
    float cross(const Vector2D& o) const;
    float length() const;
    float dist(const Vector2D& o) const;
    Vector2D normalize() const;
};

struct BoardBounds {
    float minX;
    float minY;
    float maxX;
    float maxY;
};

struct TrajectoryResult {
    bool hasHit;
    bool hasPocket;
    bool hasCushion;
    std::vector<Vector2D> strikerPath;
    std::vector<Vector2D> puckPath;
};

TrajectoryResult calculateTrajectory(
    const Vector2D& strikerPos,
    const Vector2D& aimDirection,
    const std::vector<Vector2D>& pucks,
    const std::vector<Vector2D>& pockets,
    const BoardBounds& bounds,
    float strikerRadius,
    float puckRadius,
    bool enableCushion
);

} // namespace carrom
