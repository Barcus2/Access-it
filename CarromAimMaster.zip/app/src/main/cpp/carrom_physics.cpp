#include "carrom_physics.h"
#include <cmath>
#include <algorithm>

namespace carrom {

Vector2D Vector2D::operator+(const Vector2D& o) const { return {x + o.x, y + o.y}; }
Vector2D Vector2D::operator-(const Vector2D& o) const { return {x - o.x, y - o.y}; }
Vector2D Vector2D::operator*(float s) const { return {x * s, y * s}; }
Vector2D Vector2D::operator/(float s) const { return (s != 0.0f) ? Vector2D{x / s, y / s} : Vector2D{0.0f, 0.0f}; }

float Vector2D::dot(const Vector2D& o) const { return x * o.x + y * o.y; }
float Vector2D::cross(const Vector2D& o) const { return x * o.y - y * o.x; }
float Vector2D::length() const { return std::sqrt(x * x + y * y); }
float Vector2D::dist(const Vector2D& o) const { return (*this - o).length(); }

Vector2D Vector2D::normalize() const {
    float len = length();
    return (len > 0.0001f) ? (*this / len) : Vector2D{0.0f, 0.0f};
}

TrajectoryResult calculateTrajectory(
    const Vector2D& strikerPos,
    const Vector2D& aimDirection,
    const std::vector<Vector2D>& pucks,
    const std::vector<Vector2D>& pockets,
    const BoardBounds& bounds,
    float strikerRadius,
    float puckRadius,
    bool enableCushion
) {
    TrajectoryResult result;
    result.hasHit = false;
    result.hasPocket = false;
    result.hasCushion = false;

    Vector2D dir = aimDirection.normalize();
    if (dir.length() < 0.1f) return result;

    // 1. Raycast for direct puck hit
    float closestDist = 1e9f;
    int targetPuckIdx = -1;
    Vector2D impactPoint = strikerPos;

    for (size_t i = 0; i < pucks.size(); ++i) {
        Vector2D toPuck = pucks[i] - strikerPos;
        float proj = toPuck.dot(dir);
        if (proj > 0.0f) {
            Vector2D perp = toPuck - (dir * proj);
            float dPerp = perp.length();
            float combinedRadius = strikerRadius + puckRadius;

            if (dPerp <= combinedRadius) {
                float hitDist = proj - std::sqrt(combinedRadius * combinedRadius - dPerp * dPerp);
                if (hitDist > 0.0f && hitDist < closestDist) {
                    closestDist = hitDist;
                    targetPuckIdx = static_cast<int>(i);
                    impactPoint = strikerPos + (dir * hitDist);
                }
            }
        }
    }

    if (targetPuckIdx >= 0) {
        result.hasHit = true;
        result.strikerPath = {strikerPos, impactPoint};
        
        Vector2D targetPuck = pucks[targetPuckIdx];
        Vector2D normal = (targetPuck - impactPoint).normalize();
        Vector2D puckDir = normal;

        // Find nearest pocket for target puck
        float bestPocketDist = 1e9f;
        Vector2D bestPocket = {0, 0};
        for (const auto& pocket : pockets) {
            Vector2D toPocket = pocket - targetPuck;
            if (toPocket.normalize().dot(puckDir) > 0.707f) { // ~45 deg cone
                float d = toPocket.length();
                if (d < bestPocketDist) {
                    bestPocketDist = d;
                    bestPocket = pocket;
                    result.hasPocket = true;
                }
            }
        }

        Vector2D puckEnd = result.hasPocket ? bestPocket : targetPuck + (puckDir * 600.0f);
        result.puckPath = {targetPuck, puckEnd};
        return result;
    }

    // 2. Cushion Rebound (Bank Shot) calculation
    if (enableCushion) {
        float tMin = 1e9f;
        Vector2D cushionNorm = {0, 0};
        Vector2D hitWall = strikerPos;

        // Check 4 borders
        if (dir.x > 0) {
            float t = (bounds.maxX - strikerRadius - strikerPos.x) / dir.x;
            if (t > 0 && t < tMin) { tMin = t; cushionNorm = {-1, 0}; }
        } else if (dir.x < 0) {
            float t = (bounds.minX + strikerRadius - strikerPos.x) / dir.x;
            if (t > 0 && t < tMin) { tMin = t; cushionNorm = {1, 0}; }
        }

        if (dir.y > 0) {
            float t = (bounds.maxY - strikerRadius - strikerPos.y) / dir.y;
            if (t > 0 && t < tMin) { tMin = t; cushionNorm = {0, -1}; }
        } else if (dir.y < 0) {
            float t = (bounds.minY + strikerRadius - strikerPos.y) / dir.y;
            if (t > 0 && t < tMin) { tMin = t; cushionNorm = {0, 1}; }
        }

        if (tMin < 1e9f) {
            hitWall = strikerPos + (dir * tMin);
            Vector2D reflectDir = dir - cushionNorm * (2.0f * dir.dot(cushionNorm));
            result.hasCushion = true;
            result.strikerPath = {strikerPos, hitWall, hitWall + (reflectDir * 800.0f)};
            return result;
        }
    }

    // 3. Simple extended guideline
    result.strikerPath = {strikerPos, strikerPos + (dir * 1200.0f)};
    return result;
}

} // namespace carrom
