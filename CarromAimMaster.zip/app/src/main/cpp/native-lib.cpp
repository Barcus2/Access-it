#include <jni.h>
#include "carrom_physics.h"
#include <vector>

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_aim_carrom_core_AimEngine_calculatePhysics(
    JNIEnv* env,
    jobject /* this */,
    jfloat strikerX,
    jfloat strikerY,
    jfloat aimDirX,
    jfloat aimDirY,
    jfloatArray pucksArray,
    jfloatArray pocketsArray,
    jfloat minX,
    jfloat minY,
    jfloat maxX,
    jfloat maxY,
    jfloat strikerRadius,
    jfloat puckRadius,
    jboolean enableCushion
) {
    carrom::Vector2D striker{strikerX, strikerY};
    carrom::Vector2D aimDir{aimDirX, aimDirY};
    carrom::BoardBounds bounds{minX, minY, maxX, maxY};

    std::vector<carrom::Vector2D> pucks;
    if (pucksArray != nullptr) {
        jsize len = env->GetArrayLength(pucksArray);
        jfloat* elems = env->GetFloatArrayElements(pucksArray, nullptr);
        for (int i = 0; i + 1 < len; i += 2) {
            pucks.push_back({elems[i], elems[i + 1]});
        }
        env->ReleaseFloatArrayElements(pucksArray, elems, JNI_ABORT);
    }

    std::vector<carrom::Vector2D> pockets;
    if (pocketsArray != nullptr) {
        jsize len = env->GetArrayLength(pocketsArray);
        jfloat* elems = env->GetFloatArrayElements(pocketsArray, nullptr);
        for (int i = 0; i + 1 < len; i += 2) {
            pockets.push_back({elems[i], elems[i + 1]});
        }
        env->ReleaseFloatArrayElements(pocketsArray, elems, JNI_ABORT);
    }

    carrom::TrajectoryResult result = carrom::calculateTrajectory(
        striker, aimDir, pucks, pockets, bounds,
        strikerRadius, puckRadius, enableCushion
    );

    // Pack into a float array:
    // [0] = striker path count, then x, y pairs
    // [N] = puck path count, then x, y pairs
    std::vector<float> output;
    output.push_back(static_cast<float>(result.strikerPath.size()));
    for (const auto& pt : result.strikerPath) {
        output.push_back(pt.x);
        output.push_back(pt.y);
    }
    output.push_back(static_cast<float>(result.puckPath.size()));
    for (const auto& pt : result.puckPath) {
        output.push_back(pt.x);
        output.push_back(pt.y);
    }

    jfloatArray retArray = env->NewFloatArray(output.size());
    env->SetFloatArrayRegion(retArray, 0, output.size(), output.data());
    return retArray;
}
