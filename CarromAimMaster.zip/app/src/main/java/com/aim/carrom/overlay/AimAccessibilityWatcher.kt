package com.aim.carrom.overlay

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AimAccessibilityWatcher : AccessibilityService() {

    companion object {
        const val ACTION_GAME_STATE_CHANGED = "com.aim.carrom.ACTION_GAME_STATE_CHANGED"
        const val EXTRA_IS_GAME_ACTIVE = "is_game_active"
        const val TARGET_PACKAGE = "com.miniclip.carrom"
        var isGameInForeground = false
            private set
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val currentPkg = event.packageName?.toString() ?: return
            val isActive = currentPkg == TARGET_PACKAGE

            if (isActive != isGameInForeground) {
                isGameInForeground = isActive
                val intent = Intent(ACTION_GAME_STATE_CHANGED).apply {
                    setPackage(packageName)
                    putExtra(EXTRA_IS_GAME_ACTIVE, isActive)
                }
                sendBroadcast(intent)
            }
        }
    }

    override fun onInterrupt() {}
}
