package com.aim.carrom.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import com.aim.carrom.core.AimEngine
import com.aim.carrom.core.BoardConfig

class AimCanvasView(context: Context) : View(context) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676")
        strokeWidth = 6f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4400E676")
        strokeWidth = 16f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val dashedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFD600")
        strokeWidth = 4f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(15f, 10f), 0f)
    }

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF1744")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    var boardConfig = BoardConfig()
    private var strikerPos = PointF(540f, 1600f)
    private var aimDir = PointF(0f, -1f)

    private val pockets = listOf(
        PointF(100f, 600f),
        PointF(980f, 600f),
        PointF(100f, 1480f),
        PointF(980f, 1480f)
    )

    private val mockPucks = listOf(
        PointF(540f, 1040f),
        PointF(480f, 1000f),
        PointF(600f, 1000f),
        PointF(540f, 960f)
    )

    fun updateConfig(config: BoardConfig) {
        this.boardConfig = config
        linePaint.strokeWidth = config.lineThickness
        linePaint.color = Color.parseColor(config.lineColorHex)
        glowPaint.color = Color.argb(60, Color.red(linePaint.color), Color.green(linePaint.color), Color.blue(linePaint.color))
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val trajectory = AimEngine.computeTrajectory(
            strikerPos, aimDir, mockPucks, pockets, boardConfig
        )

        // Draw Striker Trajectory (Glow + Core)
        val sPts = trajectory.strikerPoints
        if (sPts.size >= 2) {
            for (i in 0 until sPts.size - 1) {
                val p1 = sPts[i]
                val p2 = sPts[i + 1]
                if (boardConfig.enableLaserEffect) {
                    canvas.drawLine(p1.x, p1.y, p2.x, p2.y, glowPaint)
                }
                canvas.drawLine(p1.x, p1.y, p2.x, p2.y, linePaint)
            }
        }

        // Draw Target Puck Trajectory (Dashed Guide)
        val pPts = trajectory.puckPoints
        if (pPts.size >= 2) {
            for (i in 0 until pPts.size - 1) {
                val p1 = pPts[i]
                val p2 = pPts[i + 1]
                canvas.drawLine(p1.x, p1.y, p2.x, p2.y, dashedPaint)
            }
            val target = pPts.last()
            canvas.drawCircle(target.x, target.y, boardConfig.puckRadius, circlePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val dx = event.x - strikerPos.x
                val dy = event.y - strikerPos.y
                val len = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (len > 10f) {
                    aimDir = PointF(dx / len, dy / len)
                    invalidate()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
