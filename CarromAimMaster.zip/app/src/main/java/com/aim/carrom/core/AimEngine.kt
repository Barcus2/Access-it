package com.aim.carrom.core

import android.graphics.PointF

object AimEngine {

    init {
        try {
            System.loadLibrary("aimcarromcore")
        } catch (e: UnsatisfiedLinkError) {
            // Fallback for purely managed execution
        }
    }

    private external fun calculatePhysics(
        strikerX: Float,
        strikerY: Float,
        aimDirX: Float,
        aimDirY: Float,
        pucksArray: FloatArray?,
        pocketsArray: FloatArray?,
        minX: Float,
        minY: Float,
        maxX: Float,
        maxY: Float,
        strikerRadius: Float,
        puckRadius: Float,
        enableCushion: Boolean
    ): FloatArray?

    fun computeTrajectory(
        striker: PointF,
        aimDir: PointF,
        pucks: List<PointF>,
        pockets: List<PointF>,
        config: BoardConfig
    ): TrajectoryData {
        val pucksFlat = FloatArray(pucks.size * 2)
        for (i in pucks.indices) {
            pucksFlat[i * 2] = pucks[i].x
            pucksFlat[i * 2 + 1] = pucks[i].y
        }

        val pocketsFlat = FloatArray(pockets.size * 2)
        for (i in pockets.indices) {
            pocketsFlat[i * 2] = pockets[i].x
            pocketsFlat[i * 2 + 1] = pockets[i].y
        }

        try {
            val result = calculatePhysics(
                striker.x, striker.y,
                aimDir.x, aimDir.y,
                pucksFlat, pocketsFlat,
                config.minX, config.minY,
                config.maxX, config.maxY,
                config.strikerRadius, config.puckRadius,
                config.enableBankShots
            )

            if (result != null && result.isNotEmpty()) {
                var idx = 0
                val strikerCount = result[idx++].toInt()
                val strikerPts = mutableListOf<PointF>()
                for (i in 0 until strikerCount) {
                    val x = result[idx++]
                    val y = result[idx++]
                    strikerPts.add(PointF(x, y))
                }

                val puckCount = result[idx++].toInt()
                val puckPts = mutableListOf<PointF>()
                for (i in 0 until puckCount) {
                    val x = result[idx++]
                    val y = result[idx++]
                    puckPts.add(PointF(x, y))
                }

                return TrajectoryData(strikerPts, puckPts)
            }
        } catch (e: Throwable) {
            // Managed fallback calculation
        }

        // Managed Fallback Trajectory Calculation (Pure Kotlin)
        val endPoint = PointF(striker.x + aimDir.x * 800f, striker.y + aimDir.y * 800f)
        return TrajectoryData(
            strikerPoints = listOf(striker, endPoint),
            puckPoints = emptyList()
        )
    }
}
