package com.aim.carrom.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.aim.carrom.R
import com.aim.carrom.core.GameLauncherManager
import com.aim.carrom.overlay.AimOverlayService

class MainActivity : AppCompatActivity() {

    private val OVERLAY_PERMISSION_REQ_CODE = 2004

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStartAndLaunch = findViewById<Button>(R.id.btn_start_aim)
        val btnStop = findViewById<Button>(R.id.btn_stop_aim)
        val switchAutoStart = findViewById<Switch>(R.id.switch_auto_start)

        btnStartAndLaunch.setOnClickListener {
            if (checkOverlayPermission()) {
                // 1. Start the overlay engine
                AimOverlayService.start(this)

                // 2. Directly open Carrom Pool automatically!
                val launched = GameLauncherManager.launchGame(this)
                if (launched) {
                    Toast.makeText(this, "Aim Assist Running in Carrom Pool!", Toast.LENGTH_SHORT).show()
                }
            } else {
                requestOverlayPermission()
            }
        }

        btnStop.setOnClickListener {
            AimOverlayService.stop(this)
            Toast.makeText(this, "Aim Assist Stopped.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE)
            Toast.makeText(this, "Please enable 'Display over other apps'", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (checkOverlayPermission()) {
                AimOverlayService.start(this)
                GameLauncherManager.launchGame(this)
            } else {
                Toast.makeText(this, "Overlay permission is required for aim assist", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
