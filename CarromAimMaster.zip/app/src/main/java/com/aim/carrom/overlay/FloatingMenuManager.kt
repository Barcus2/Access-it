package com.aim.carrom.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Switch
import com.aim.carrom.R
import com.aim.carrom.core.BoardConfig

class FloatingMenuManager(
    private val context: Context,
    private val onConfigChanged: (BoardConfig) -> Unit,
    private val onClose: () -> Unit
) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var floatView: View? = null
    private var menuPanel: View? = null
    private var isMenuOpen = false

    private var currentConfig = BoardConfig()

    fun show() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        val inflater = LayoutInflater.from(context)
        val root = inflater.inflate(R.layout.layout_floating_menu, null)
        floatView = root

        val iconBtn = root.findViewById<ImageView>(R.id.btn_float_icon)
        val panel = root.findViewById<View>(R.id.panel_menu)
        val switchBank = root.findViewById<Switch>(R.id.switch_bank_shots)
        val switchLaser = root.findViewById<Switch>(R.id.switch_laser)
        val btnClose = root.findViewById<View>(R.id.btn_close_overlay)
        menuPanel = panel

        switchBank.isChecked = currentConfig.enableBankShots
        switchLaser.isChecked = currentConfig.enableLaserEffect

        switchBank.setOnCheckedChangeListener { _, isChecked ->
            currentConfig = currentConfig.copy(enableBankShots = isChecked)
            onConfigChanged(currentConfig)
        }

        switchLaser.setOnCheckedChangeListener { _, isChecked ->
            currentConfig = currentConfig.copy(enableLaserEffect = isChecked)
            onConfigChanged(currentConfig)
        }

        btnClose.setOnClickListener {
            hide()
            onClose()
        }

        // Dragging & Tapping logic
        iconBtn.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = true

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                            params.x = initialX + dx
                            params.y = initialY + dy
                            windowManager.updateViewLayout(floatView, params)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            isMenuOpen = !isMenuOpen
                            panel.visibility = if (isMenuOpen) View.VISIBLE else View.GONE
                        }
                        return true
                    }
                }
                return false
            }
        })

        windowManager.addView(root, params)
    }

    fun setVisibility(visibility: Int) {
        floatView?.visibility = visibility
    }

    fun hide() {
        floatView?.let {
            windowManager.removeView(it)
            floatView = null
        }
    }
}
