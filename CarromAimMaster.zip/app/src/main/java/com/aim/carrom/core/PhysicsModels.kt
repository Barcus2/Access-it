package com.aim.carrom.core

import android.graphics.PointF

data class TrajectoryData(
    val strikerPoints: List<PointF>,
    val puckPoints: List<PointF>
)

data class BoardConfig(
    val minX: Float = 50f,
    val minY: Float = 50f,
    val maxX: Float = 1030f,
    val maxY: Float = 1030f,
    val strikerRadius: Float = 35f,
    val puckRadius: Float = 28f,
    val enableBankShots: Boolean = true,
    val enableLaserEffect: Boolean = true,
    val lineColorHex: String = "#00FF66",
    val lineThickness: Float = 6f
)
