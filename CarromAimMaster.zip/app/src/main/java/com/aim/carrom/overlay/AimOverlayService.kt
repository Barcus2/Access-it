package com.aim.carrom.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.aim.carrom.R
import com.aim.carrom.ui.MainActivity

class AimOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var canvasView: AimCanvasView? = null
    private var floatingMenu: FloatingMenuManager? = null

    private val gameReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AimAccessibilityWatcher.ACTION_GAME_STATE_CHANGED) {
                val isGameActive = intent.getBooleanExtra(AimAccessibilityWatcher.EXTRA_IS_GAME_ACTIVE, false)
                setOverlayVisibility(isGameActive)
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "carrom_aim_overlay_channel"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, AimOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AimOverlayService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        setupOverlayViews()

        val filter = IntentFilter(AimAccessibilityWatcher.ACTION_GAME_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(gameReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(gameReceiver, filter)
        }
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Aim Assist Running",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Carrom Aim Engine Active")
            .setContentText("Game-bound mode: Automatically active when Carrom Pool is open")
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun setupOverlayViews() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )

        canvasView = AimCanvasView(this)
        windowManager.addView(canvasView, canvasParams)

        floatingMenu = FloatingMenuManager(
            this,
            onConfigChanged = { newConfig ->
                canvasView?.updateConfig(newConfig)
            },
            onClose = {
                stopSelf()
            }
        )
        floatingMenu?.show()
    }

    fun setOverlayVisibility(visible: Boolean) {
        val visibility = if (visible) View.VISIBLE else View.GONE
        canvasView?.visibility = visibility
        floatingMenu?.setVisibility(visibility)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(gameReceiver)
        } catch (e: Exception) {
            // Ignore
        }
        canvasView?.let {
            windowManager.removeView(it)
            canvasView = null
        }
        floatingMenu?.hide()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
